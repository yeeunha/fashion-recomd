# kdata_fashion

https://paradise999.tistory.com/9 <br>
위 링크 참고해서 가상환경 설정 후 제대로 작동되는지 확인한 뒤에 수정하면 될 것 같습니다!
